import game.GameElement;

import java.util.Locale;
import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Введите ROCK,SCISSORS,PAPER");
        String userStr = new Scanner(System.in).nextLine();
        GameElement userChoice = GameElement.valueOf(userStr.toUpperCase(Locale.ROOT));

        Random random = new Random();
        int compNum = random.nextInt( 3);
        GameElement compChoice = switch (compNum){
            case 0 -> GameElement.ROCK;
            case 1 -> GameElement.PAPER;
            default -> GameElement.SCISSORS;

        };
        System.out.println(compChoice);

        if (userChoice==compChoice){
            System.out.println("ничья");
        }else{
            if (userChoice==GameElement.ROCK && compChoice==GameElement.SCISSORS ||
                    userChoice==GameElement.SCISSORS && compChoice==GameElement.PAPER ||
                    userChoice==GameElement.PAPER && compChoice==GameElement.ROCK ){
                System.out.println("Вы победили");
            }else{
                System.out.println("Победил компьютер");
            }
        }

    }
}