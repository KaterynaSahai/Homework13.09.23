import Godiki.Anniversary;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Сколько лет вы в браке?");
        int num=new Scanner(System.in).nextInt();
        Anniversary weeding = switch (num){
            case 1 -> Anniversary.SITTSEVAYA;
            case 2 -> Anniversary.BUMAZHNAYA;
            case 3 -> Anniversary.KOZHANAYA;
            case 4 -> Anniversary.LNYANAYA;
            case 5 -> Anniversary.DEREVYANAYA;
            case 6 -> Anniversary.CHUGUNNAYA;
            case 7 -> Anniversary.MEDNAYA;
            case 8 -> Anniversary.ZHESTYANAYA;
            case 9 -> Anniversary.FAYANSOVAYA;
            case 10 -> Anniversary.OLOVYANNAYA;
            default -> throw new RuntimeException("неизвестная годовщина");

        };
        System.out.println(num);
        String description = switch (weeding){
            case SITTSEVAYA -> "Следующая годовщина бумажная";
            case BUMAZHNAYA -> "Следующая годовщина кожаная";
            case KOZHANAYA -> "Следующая годовщина льняная";
            case LNYANAYA -> "Следующая годовщина деревяная";
            case DEREVYANAYA -> "Следующая годовщина чугунная";
            case CHUGUNNAYA -> "Следующая годовщина медная";
            case MEDNAYA -> "Следующая годовщина жестяная";
            case ZHESTYANAYA -> "Следующая годовщина фаянсовая";
            case FAYANSOVAYA -> "Следующая годовщина оловяная";
            case OLOVYANNAYA -> "Следующая годовщина стальная";
        };
        System.out.println(description);

    }
}