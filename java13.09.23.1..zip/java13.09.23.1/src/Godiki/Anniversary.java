package Godiki;

public enum Anniversary {
    SITTSEVAYA,
    BUMAZHNAYA,
    KOZHANAYA,
    LNYANAYA,
    DEREVYANAYA,
    CHUGUNNAYA,
    MEDNAYA,
    ZHESTYANAYA,
    FAYANSOVAYA,
    OLOVYANNAYA
}
